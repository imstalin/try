import math
import os
import pandas as pd
import time , numpy as np , requests  as req
import json
from dateutil.relativedelta import relativedelta
from datetime import datetime

import indicators as tid

tradeResults = []
closedTrades = []
marginTrades =[]

def GetInstrumentData(startdt,enddt ,instrumentid,specificinterval):  
    authorization = "enctoken 9QN9sIQRyAhi3zm0QCS5U0nrWbtWvFKk5nUE313MrT837rD8DMygYS72oYor2JXUs0+3+V0cN8ClQJ7wlgCa6tf51P2QxVfGVql0DZaraOOXrQZdS5L98w=="
    url="https://kite.zerodha.com/oms/instruments/historical/"+str(instrumentid)+"/"+str(specificinterval)+"?user_id=ZW6964&oi=1&from="+startdt+"&to="+enddt+"&ciqrandom=1582995271093"
    headers = {"authorization":authorization}
    r = req.get(url,headers=headers) 
    loaded_data = r.json()  
    del loaded_data["status"] 
    df = pd.DataFrame(loaded_data["data"]["candles"], columns=['date', 'Open', 'High', 'Low', 'Close', 'volume', "count"]) 
    return df

lotsize = 50
runLive =3
while runLive < 4:
    f = open('ins_bank.json') 
    data = json.load(f)
    for row in data:
        print(row["InstrumentName"])

        for closed in closedTrades:
            if closed == row["InstrumentName"]:
                break

        day=0
        fileName=row["InstrumentName"]+"_"+str(day)+".xlsx"
        a_3month = relativedelta(days=day)    

        now = datetime.now()

        startDate,endDate,token,interval="2021-09-08","2021-11-09","260105","3minute"
        bnf_token = row["InstrumentID"] #"256265"
        startDate = now - a_3month
        startDate = startDate.strftime("%Y-%m-%d") 
        #startDate = "2022-03-02"
        endDate = startDate#now.strftime("%Y-%m-%d")
        token = bnf_token


        df = GetInstrumentData(startDate,endDate,token,"3minute")        
        #df = df.loc[1:runLive]

        df["sumSrcVol"] = 0.0
        df["sumVol"]=0.0
        df["sumSrcSrcVol"] = 0.0
        df["VWAP"]=0.0
        df["variance"]=0
        df["stDev"]=0
        df["lowerBand"]=0
        df["upperBand"]=0
        df["LowVal"]=0
        df["Entry"]=0
        df["StopLoss"]=0
        df["Target"]=0
        df["Profit"]=0
        df["Loss"]=0



        period = 20
        stDevMultiplier = 2
        for i in range(0, len(df)):
            src = (df["High"].iat[i]+df["Low"].iat[i]+df["Close"].iat[i])/3
            if(i==0):        
                df["sumSrcVol"].iat[i] = (src )* df["volume"].iat[i]
                df["sumVol"].iat[i] = df["volume"].iat[i]
                df["sumSrcSrcVol"].iat[i] = df["volume"].iat[i] * pow(src, 2) 
            else:
                df["sumSrcVol"].iat[i] = (src )* df["volume"].iat[i] + df["sumSrcVol"].iat[i-1]
                df["sumVol"].iat[i] = df["volume"].iat[i] + df["sumVol"].iat[i-1]
                df["sumSrcSrcVol"].iat[i] = df["volume"].iat[i] * pow(src, 2) + df["sumSrcSrcVol"].iat[i-1]

            df["VWAP"].iat[i]= df["sumSrcVol"].iat[i]/df["sumVol"].iat[i]
            df["variance"].iat[i]= df["sumSrcSrcVol"].iat[i]/df["sumVol"].iat[i] - pow(df["VWAP"].iat[i], 2) 
            df["variance"].iat[i] = 0 if (df["variance"].iat[i] < 0) else df["variance"].iat[i]
            df["stDev"].iat[i] = math.sqrt(df["variance"].iat[i])

            df["lowerBand"].iat[i] = df["VWAP"].iat[i] - (df["stDev"].iat[i] * stDevMultiplier)
            df["upperBand"].iat[i] = df["VWAP"].iat[i] + (df["stDev"].iat[i] * stDevMultiplier)
            df["LowVal"].iat[i] = df["Low"].iat[i] - df["lowerBand"].iat[i]




        #tid.SMA(df,base="Close", target="SMA_20",period=20)
        tid.SuperTrend(df,period=10,multiplier=2)

        for i in range(0, len(df)):
            if(df["LowVal"].iat[i]<=0):
                if(df["Open"].iat[i] < df["Close"].iat[i]):
                    df["Entry"].iat[i] =df["Open"].iat[i]
                else:
                    df["Entry"].iat[i] =df["Close"].iat[i]
                df["StopLoss"].iat[i] =df["Entry"].iat[i] - (df["TR"].iat[i]*2)
                if(df["VWAP"].iat[i] <=(df["Entry"].iat[i] + df["TR"].iat[i])):
                    df["Target"].iat[i] =df["VWAP"].iat[i] 
                else:                     
                    df["Target"].iat[i] =df["Entry"].iat[i] + df["TR"].iat[i]
                df["Profit"].iat[i] = (df["Target"].iat[i] - df["Entry"].iat[i])*lotsize
                df["Loss"].iat[i] =(df["StopLoss"].iat[i] - df["Entry"].iat[i])*lotsize



        df.to_excel(fileName)
        

        readDF = pd.read_excel(fileName)
        for i in range(1,len(readDF)):
            entry = readDF["Entry"].iat[i]
            stoploss = readDF["StopLoss"].iat[i]
            target = readDF["Target"].iat[i]
            safeTarget = readDF["Entry"].iat[i] + 5
            if(entry!=0):
                print("Signal Time ", readDF["date"].iat[i] , "Buy Price ", entry )
                break


        isTradeExecuted = False
        isProfitBooked = False
        isStopLossHit = False

        for i in range(4,len(readDF)):    
            if(isTradeExecuted == False):
                if(readDF["Low"].iat[i]<=entry):
                    marginTrades.append(entry*lotsize)
                    print("Trade Executed " , readDF["date"].iat[i] , "Entry ", entry , "Stop Loss ",stoploss , " Target ", target)
                    isTradeExecuted = True      

            # if(i==55):
            #     if(round(float(readDF["High"].iat[i]) - float(entry))> 0):
            #         isProfitBooked = True
            #     else:
            #         isStopLossHit = True 


                
            if(readDF["Low"].iat[i]<= stoploss and isTradeExecuted== True ):
                print("Stop Loss Hit ", round(float(readDF["Low"].iat[i]) - float(entry))*lotsize)
                isStopLossHit = True  

            if(isProfitBooked == False and isTradeExecuted== True):
                # print("Profit Booked ", round(float(readDF["High"].iat[i]) - float(entry)) , "Date & Time " , readDF["date"].iat[i])
                # print("Profit ", round(float(readDF["High"].iat[i]) - float(entry))*lotsize)
                # isProfitBooked = True
                if(readDF["High"].iat[i]>=target):                    
                    if(readDF["High"].iat[i]>=target):
                        print("Profit Booked ", round(float(readDF["High"].iat[i]) - float(entry)) , "Date & Time " , readDF["date"].iat[i])
                        print("Profit ", round(float(readDF["High"].iat[i]) - float(entry))*lotsize)
                        # print("Profit Booked ", round(float(readDF["High"].iat[i+1]) - float(entry)) , "Date & Time " , readDF["date"].iat[i+1])
                        # print("Profit ", round(float(readDF["High"].iat[i+1]) - float(entry))*lotsize)
                        # print("Profit Booked ", round(float(readDF["High"].iat[i+2]) - float(entry)) , "Date & Time " , readDF["date"].iat[i+2])
                        # print("Profit ", round(float(readDF["High"].iat[i+2]) - float(entry))*lotsize)
                        # print("Profit Booked ", round(float(readDF["High"].iat[i+3]) - float(entry)) , "Date & Time " , readDF["date"].iat[i+3])
                        # print("Profit ", round(float(readDF["High"].iat[i+3]) - float(entry))*lotsize)
                        isProfitBooked = True

                  

            if(isTradeExecuted == True and isProfitBooked== False and isStopLossHit == False):
                print("Trade is running!!! , Time ",readDF["date"].iat[i] , "  Price ", float(readDF["High"].iat[i]) ," points ",round(float(readDF["High"].iat[i]) - float(entry)))
            elif isTradeExecuted == False:
                print("Waiting for Opporunities ", readDF["date"].iat[i])   

            if((isStopLossHit== True or isProfitBooked==True) and isTradeExecuted== True ):
                if(isStopLossHit== False):
                    tradeResults.append((round(target - float(entry))*lotsize)-80)
                else:
                    tradeResults.append((round(float(readDF["Low"].iat[i]) - float(entry))*lotsize)-80)
                closedTrades.append(row["InstrumentName"])
                print("Trade is Closed!!!")
                break
            
            time.sleep(0.001)
    runLive = runLive +1
print("===========================")
for i in tradeResults:
    print(i)

print("Total Profit " , sum(tradeResults))
print("Total Margins ", sum(marginTrades) )
        





    
        
        
