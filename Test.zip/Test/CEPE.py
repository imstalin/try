import os
from numpy.core.numeric import tensordot
from numpy.lib.function_base import average
import pandas as pd
import time , numpy as np , requests  as req

from dateutil.relativedelta import relativedelta
from datetime import datetime, timedelta
import indicators as tid

def GetInstrumentData(startdt,enddt ,instrumentid,specificinterval):  
    authorization = "enctoken O5xRLUagNcX2ezdfC/eXmzYjKkOny6zFUPTPxUA6IRuPN5lYSKG6NWZa6HGEOXtYzVWhVh2oZUH7wbFy7nbUeIgcZUenTJM9fVc2Z2B7aqdOyf9fOGnijw=="
    url="https://kite.zerodha.com/oms/instruments/historical/"+str(instrumentid)+"/"+str(specificinterval)+"?user_id=ZW6964&oi=1&from="+startdt+"&to="+enddt+"&ciqrandom=1582995271093"
    headers = {"authorization":authorization}
    r = req.get(url,headers=headers) 
    loaded_data = r.json()  
    del loaded_data["status"] 
    df = pd.DataFrame(loaded_data["data"]["candles"], columns=['date', 'Open', 'High', 'Low', 'Close', 'volume', "count"]) 
    return df
#16223234
#13092866-Expired
strikePrice = "17000CE"
minDF = GetInstrumentData("2021-12-17","2021-12-23" ,"16174338","minute")
#minDF = pd.read_excel("CEPE21.xlsx")

period, multiplier = 10,2.2
#tid.HA(minDF)
tid.SuperTrendTest(minDF, period, multiplier, ohlc=['Open', 'High', 'Low', 'Close'])

minDF.to_excel("CEPE23.xlsx")

#print(minDF)
datatypes = minDF.dtypes
minDF['date'] =  pd.to_datetime(minDF['date'], infer_datetime_format=True)
#print(minDF.head())
#print(datatypes)
  

endDate = "2021-12-23 09:15:00+05:30"
datetime_object = datetime.strptime(endDate, '%Y-%m-%d %H:%M:%S+05:30')

result = pd.DataFrame(columns = ['DateTime', 'Entry','Close','ST'])
while True: 
    
    startDate = "2021-12-23 09:15:00+05:30"    
    endDatetime_object = datetime.strptime(endDate, '%Y-%m-%d %H:%M:%S+05:30')
    endDatetime_object= endDatetime_object  + timedelta(minutes=1)
    endDate = datetime.strftime(endDatetime_object,'%Y-%m-%d %H:%M:%S+05:30')
   
    if (endDate == "2021-12-23 15:15:00+05:30"):
        break
    todayMin = minDF.loc[minDF["date"].between("2021-12-23 09:15:00+05:30",endDate)]
    
    if(len(todayMin)   > 5):
        last5rows = todayMin.tail(5)
        last5rowsST_10_2_2 = todayMin["ST_10_2.2"].tail(5)
        last5rowsClose = todayMin["Close"].tail(5)
        stavg = todayMin["ST_10_2.2"].tail(5).mean()
        trend = todayMin["STX_10_2.2"].tail(1).iloc[0]
        
        if(trend == "down"):            
            for i in range(0,len(last5rowsST_10_2_2)):        
                firstRow = last5rowsST_10_2_2.iloc[i]
                firstCloseRow = last5rowsClose.iloc[i]
                if(last5rows["Open"].iloc[i] <= last5rows["Close"].iloc[i]):
                    firstCloseRow=last5rows["Open"].iloc[i]

                lastCloseRow = last5rowsClose.iloc[i+4]
                break

            if(stavg == firstRow):
                if(len(result.loc[result["ST"]==stavg])==0):
                    result = result.append({"DateTime": endDate, "Entry":firstCloseRow, "Close": lastCloseRow , "ST":stavg},ignore_index = True)
       
    #time.sleep(0.1)
result["Avg"] = result["Entry"].rolling(window=2).mean()
result["Status"] = result["Close"] > result["Avg"]

result.to_excel("OutPutCEPE21.xlsx")
print("----------- Strike Price {} ---------".format(strikePrice))
print(result) 