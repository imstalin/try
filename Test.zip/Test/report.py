import os
import pandas as pd
# Get the list of all files and directories
# path = "trades"
# dir_list = os.listdir(path)

# i = 0
# for path, subdirs, files in os.walk(path):
#     for name in files: 
#         print(os.path.join(path, name))
#         df = pd.read_json(os.path.join(path, name))
#         df.to_csv("sample{}.csv".format(i))
#         i = i+1

df = pd.read_excel("trades.xlsx")
df['date'] = pd.to_datetime(df['endTimestamp'],unit='s')
#df['endTimestamp'].map(lambda x: pd.to_datetime(x, yearfirst=True).tz_convert('asia/kolkata'))

df.to_excel("output.xlsx")


 


