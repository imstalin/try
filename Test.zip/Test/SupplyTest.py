import os
import pandas as pd
import time , numpy as np , requests  as req

from dateutil.relativedelta import relativedelta
from datetime import datetime

import indicators as tid

def GetInstrumentData(startdt,enddt ,instrumentid,specificinterval):  
    authorization = "enctoken DJBUUo6zBImE0xhP+TONNVcq6fQNf4+ibzYdbVJwkxENUSFX3GPYPbkPOx+P0TqygX3JShx45RjKUQ8R/G6039NLQ8tLzZ5XD/21de6dlOByJfurAtXYcA=="
    url="https://kite.zerodha.com/oms/instruments/historical/"+str(instrumentid)+"/"+str(specificinterval)+"?user_id=ZW6964&oi=1&from="+startdt+"&to="+enddt+"&ciqrandom=1582995271093"
    headers = {"authorization":authorization}
    r = req.get(url,headers=headers) 
    loaded_data = r.json()  
    del loaded_data["status"] 
    df = pd.DataFrame(loaded_data["data"]["candles"], columns=['date', 'Open', 'High', 'Low', 'Close', 'volume', "count"]) 
    return df

a_3month = relativedelta(months=3)    

now = datetime.now()

startDate,endDate,token,interval="2021-09-08","2021-11-09","260105","5minute"
bnf_token = "260105"#"256265"
startDate = now - a_3month
startDate = startDate.strftime("%Y-%m-%d") 
endDate = now.strftime("%Y-%m-%d")
token = bnf_token


df = GetInstrumentData(startDate,endDate,token,"3minute")

df["CandLeType"] = ""
df["BodyRange"] = 0
df["CandleRange"] = 0
df["Crossing"]=""
df["CandleColor"]=""
df["Zone"]=""
tid.SMA(df,base="Close", target="SMA_20",period=20)

for i in range(1,len(df)):
    if(df["Close"].iat[i] >= df["Open"].iat[i]):
        df["BodyRange"].iat[i] = df["Close"].iat[i] - df["Open"].iat[i]
        df["CandleRange"].iat[i] = df["High"].iat[i] - df["Low"].iat[i]
    else:
        df["BodyRange"].iat[i] = df["Open"].iat[i] - df["Close"].iat[i]
        df["CandleRange"].iat[i] = df["High"].iat[i] - df["Low"].iat[i]

    if(df["Close"].iat[i] >= df["Open"].iat[i]):
        df["CandleColor"].iat[i] ="Green"
    
    if(df["Close"].iat[i] <= df["Open"].iat[i]):
        df["CandleColor"].iat[i] ="Red"
    
    if(df["Close"].iat[i] == df["Open"].iat[i]):
        df["CandleColor"].iat[i] ="Doji"
    

    #50% Chandle Range
    per50 = df["CandleRange"].iat[i]*(50/100)

    if(df["BodyRange"].iat[i]<=per50):
        df["CandLeType"].iat[i]="T"
    else:
        df["CandLeType"].iat[i]="IB"

    if(df["Close"].iat[i] >=df["SMA_20"].iat[i]):
        df["Crossing"].iat[i] = "True"
    else:
        df["Crossing"].iat[i] = "False"

    if(i>=4):
        if(df["CandLeType"].iat[i]=="IB" and df["CandLeType"].iat[i-1]=="T"  and df["CandLeType"].iat[i-2]=="T" and df["CandLeType"].iat[i-3]=="IB" ):
            df["Zone"].iat[i]="Demand Zone - 2 Level"
    
    if(df["Zone"].iat[i]==""):
        if(i>=3):
            if(df["CandLeType"].iat[i]=="IB" and df["CandLeType"].iat[i-1]=="T"  and df["CandLeType"].iat[i-2]=="IB" ):
                df["Zone"].iat[i]="Demand Zone - 1 Level"

    if(df["Zone"].iat[i] !="Demand Zone - 1 Level" and df["Zone"].iat[i]==""):
        if(i>=4):
            if(df["CandLeType"].iat[i]=="IB" and df["CandLeType"].iat[i-1]=="T" and df["CandLeType"].iat[i-2]=="T"  and df["CandLeType"].iat[i-3]=="IB" ):
                df["Zone"].iat[i]="Demand Zone - 2 Level"
    
    if(df["Zone"].iat[i] !="Demand Zone - 1 Level" and df["Zone"].iat[i] !="Demand Zone - 2 Level" and df["Zone"].iat[i]==""):
        if(i>=5):
            if(df["CandLeType"].iat[i]=="IB" and df["CandLeType"].iat[i-1]=="T" and df["CandLeType"].iat[i-2]=="T" and df["CandLeType"].iat[i-3]=="T"  and df["CandLeType"].iat[i-4]=="IB" ):
                df["Zone"].iat[i]="Demand Zone - 3 Level"
            




    

df.to_excel("Supply.xlsx")
 


 
    
    
