// Javascript example.
var ws = new WebSocket("wss://ws.zerodha.com/?api_key=kitefront&user_id=ZW6964&enctoken=Z5mwEHFAzTHZpgVHQ1LhSbCB%2BkszrUqZeGr%2BjNiaFJMO2QFbbzORsoNkkWxtUo6UsdpOwa2fh5pUoUojjHv%2FxuZSyEhYfPOysSUNNnWabSdeyV3eXlxs0w%3D%3D&uid=1641058962322&user-agent=kite3-web&version=2.9.10");


console.log(ws);

var message = {"a": "subscribe", "v": [408065, 884737]};
ws.send(JSON.stringify(message))
