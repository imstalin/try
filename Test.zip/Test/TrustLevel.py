import os
import pandas as pd
import time , numpy as np , requests  as req

from dateutil.relativedelta import relativedelta
from datetime import datetime


def GetInstrumentData(startdt,enddt ,instrumentid,specificinterval):  
    authorization = "enctoken MpS2AVmSQwa8Y1abyntUI0WlDE15f7s55a1fVSwucsqhJp79bcU1T/VhjJdAOJxRk0HAGNF909iwXzGq/SDs+N7vkRa/biX+rj9d2CFGbbMEASy/W/JvMQ=="
    url="https://kite.zerodha.com/oms/instruments/historical/"+str(instrumentid)+"/"+str(specificinterval)+"?user_id=ZW6964&oi=1&from="+startdt+"&to="+enddt+"&ciqrandom=1582995271093"
    headers = {"authorization":authorization}
    r = req.get(url,headers=headers) 
    loaded_data = r.json()  
    del loaded_data["status"] 
    df = pd.DataFrame(loaded_data["data"]["candles"], columns=['date', 'Open', 'High', 'Low', 'Close', 'volume', "count"]) 
    return df

a_3month = relativedelta(months=3)    

now = datetime.now()

startDate,endDate,token,interval="2021-09-08","2021-11-09","260105","5minute"
bnf_token = "260105"
startDate = now - a_3month
startDate = startDate.strftime("%Y-%m-%d") 
endDate = now.strftime("%Y-%m-%d")
token = bnf_token


daydf = GetInstrumentData(startDate,endDate,token,"day")
daydf.loc[len(daydf.index)] = daydf.loc[len(daydf.index)-1] 

daydf["PivotPoint"] = 0.0
daydf["S1"] = 0.0
daydf["S2"] = 0.0
daydf["S3"] = 0.0
daydf["R1"] = 0.0
daydf["R2"] = 0.0
daydf["R3"] = 0.0

daydf["TPP"] = 0.0
daydf["BPP"] = 0.0

daydf["PDH"] = 0.0
daydf["PDL"] = 0.0

daydf["OpenAboveR1"] =""
daydf["OpenAbovePDH"] =""

daydf["OpenBelowS1"] =""
daydf["OpenBelowPDL"] =""

daydf["OpenBetweenR1andPP"] =""
daydf["OpenBetweenS1andPP"] =""

daydf["OpenAtPP"] =""

for i in range(1,len(daydf)):

    high = daydf["High"].iat[i-1]
    low = daydf["Low"].iat[i-1]
    close = daydf["Close"].iat[i-1]

    pp = round((high + low + close) / 3,2)
    r1 = round((2*pp) - low,2)
    s1 = round((2*pp) - high,2)

    r2 =  round(pp + (high-low),2)
    s2 =  round(pp - (high-low),2)

    r3 =  round(pp + 2 * (high-low),2)
    s3 =  round(pp - 2 * (high-low),2)

    bcpr = round((high + low) /2,2)
    tcpr = round((pp-bcpr)+pp,2)
    cprPer = abs((tcpr - pp) / pp * 100)

    daydf["PivotPoint"].iat[i] = pp
    daydf["S1"].iat[i] = s1
    daydf["S2"].iat[i] = s2
    daydf["S3"].iat[i] = s3
    daydf["R1"].iat[i] = r1
    daydf["R2"].iat[i] = r2
    daydf["R3"].iat[i] = r3

    daydf["BPP"].iat[i] = tcpr
    daydf["TPP"].iat[i] = bcpr

    daydf["PDH"].iat[i] = high
    daydf["PDL"].iat[i] = low


daydf.to_excel("Levels.xlsx")

readLevel = pd.read_excel("Levels.xlsx")

current = len(readLevel)-1


for j in range(current,len(readLevel)):
    print(j)
    #date=readLevel["date"].iat[i]
    date = now = datetime.now()
    startDate = date.strftime("%Y-%m-%d") 
    endDate = date.strftime("%Y-%m-%d")
    df = GetInstrumentData(startDate,endDate,token,"5minute")
    first3fiveminutes = df.head(3)

    #Check open price is above R1 or Below S1
    closemin = first3fiveminutes["Close"].min()
    closemax = first3fiveminutes["Close"].max()
    currentDay = readLevel.loc[j-1]    
    
    columns = ["LevelName","Levels", "Distance", "ClosePrice"]

    newData = pd.DataFrame(columns= columns)
    newData["LevelName"] = ["PivotPoint","TPP","BPP","R1","S1","PDL","PDH"]
    newData["ClosePrice"] = abs(closemax)
    newData["Levels"] = [currentDay["PivotPoint"],currentDay["TPP"],currentDay["BPP"],currentDay["R1"],currentDay["S1"],currentDay["PDL"],currentDay["PDH"]]
    newData["Levels"] = abs(newData["Levels"])
   
    newData["Distance"] = newData["ClosePrice"] - newData["Levels"]
    ChecksEntry = ["OpenAboveR1orPDH","OpenBelowS1orPDL","OpenBetweenPPandR1","OpenBetweenPPandS1","OpenAtPP"]

    for i in range(0,len(ChecksEntry)):
        if(ChecksEntry[i] == "OpenAtPP"):
            data = newData.loc[newData["LevelName"].isin(["TPP","BPP","PivotPoint"])]
            minLevel = data["Levels"].min()
            maxLevel = data["Levels"].max()

            if( minLevel <= closemax and closemax>=maxLevel):
                print("Open at Pivot Point Range")
                print("Trade only R1,PDH - High Broken / S1,PDL Low Broken")
        
        if(ChecksEntry[i] == "OpenBelowS1orPDL"):
            data = newData.loc[newData["LevelName"].isin(["S1","PDL"])]
            minLevel = data["Levels"].min()
            maxLevel = data["Levels"].max()
            if(closemax >= minLevel or closemax >= maxLevel):
                print("First Level support is likely to break or broken")
                print("Morning, It will attrac PivotPoint")
        
        if(ChecksEntry[i] == "OpenAboveR1orPDH"):
            data = newData.loc[newData["LevelName"].isin(["R1","PDH"])]
            minLevel = data["Levels"].min()
            maxLevel = data["Levels"].max()
            if(closemax >= minLevel or closemax >= maxLevel):
                print("First Level resistance is likely to break or broken")
                print("Morning, It will attrac PivotPoint")
        
        if(ChecksEntry[i] == "OpenBetweenPPandR1"):
            data = newData.loc[newData["LevelName"].isin(["R1","PDH","TPP"])]
            minLevel = data["Levels"].min()
            maxLevel = data["Levels"].max()
            if(closemax >= minLevel or closemax >= maxLevel):
                print("First Level resistance is likely to break or broken")
                print("Morning, It will attrac PivotPoint")

        if(ChecksEntry[i] == "OpenBetweenPPandS1"):
            data = newData.loc[newData["LevelName"].isin(["S1","PDL","BPP"])]
            minLevel = data["Levels"].min()
            maxLevel = data["Levels"].max()
            if(closemax >= minLevel or closemax >= maxLevel):
                print("First Level resistance is likely to break or broken")
                print("Morning, It will attrac PivotPoint")
        



    

    #Write Code other way  Selling - S1    

    #Reversal Tricks
    #1.
    #Price at R1 and PDH, if that doesn't broke in the morning
    #Calculate distance between CMP and R1/PDH

    #2.
    #Price at S1 and PDL, if that doesn't broke in the morning
    #Calculate distance between CMP and S1/PDL
    #If Price near S1 ,Buy CE and Target to PP, Stop Loss is 50% of distance between S1 and S2
    #IF Price is near PivotPoint , By PE and Traget  to S1 , Stop is 50% of between PP and R1
    



 
    
    
